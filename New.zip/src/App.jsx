import './App.css'
import MapCards from './MapCards/MapCards'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Anjir from './Maps/Anjir';

function App() {

  return (
    <>

      <Router>
        <Routes>
          <Route path="/" element={<MapCards />} />
          <Route path="/maps/:title" element={<Anjir />} />
        </Routes>
      </Router>
      
    </>
  )
}
export default App;