import React from "react";

function Chor() {

    return(
        <>
        
        </>
    )

}
export default Chor;