import React from "react";

function Qanotchi() {

    return(
        <>
        
        </>
    )

}
export default Qanotchi;