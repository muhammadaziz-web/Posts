import React from "react";

function Bosphorus() {

    return(
        <>
        
        </>
    )

}
export default Bosphorus;