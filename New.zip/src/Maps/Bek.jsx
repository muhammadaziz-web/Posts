import React from "react";

function Bek() {

    return(
        <>
        
        </>
    )

}
export default Bek;