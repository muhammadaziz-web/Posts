import React from "react";

function MarMar() {

    return(
        <>
            <h1>
                Mar Mar Rossiya
            </h1>
        </>
    )

}
export default MarMar;