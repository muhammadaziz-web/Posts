import React from "react";

function Bosphorus() {

    return(
        <>
            <h1>
                Bosphorus Viaport
            </h1>
        </>
    )

}
export default Bosphorus;