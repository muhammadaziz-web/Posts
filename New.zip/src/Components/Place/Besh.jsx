import React from "react";

function Besh() {

    return(
        <>
            <h1>
                Besh Qozon Glinka
            </h1>
        </>
    )

}
export default Besh;