import React from "react";

function Anor() {

    return(
        <>
            <h1>
                Anor Rossiya
            </h1>
        </>
    )

}
export default Anor;