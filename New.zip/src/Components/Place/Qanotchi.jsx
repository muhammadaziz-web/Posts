import React from "react";

function Qanotchi() {

    return(
        <>
            <h1>
                Qanotchi Qushbegi
            </h1>
        </>
    )

}
export default Qanotchi;