import React from "react";

function Bek() {

    return(
        <>
            <h1>
                Bek Osiyo Yakkasaroy
            </h1>
        </>
    )

}
export default Bek;