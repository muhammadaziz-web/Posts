import React from "react";

function SimSim() {

    return(
        <>
            <h1>
                Sim Sim Muqimiy
            </h1>
        </>
    )

}
export default SimSim;