import React from "react";

function Donerci() {

    return(
        <>
            <h1>
                Donerci hamdi usta Glinka
            </h1>
        </>
    )

}
export default Donerci;