import React from "react";

function Chor() {

    return(
        <>
            <h1>
                Chor minor
            </h1>
        </>
    )

}
export default Chor;