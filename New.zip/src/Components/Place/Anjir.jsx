import React from "react";


function Anjir() {

    return(
        <>
            <h1>
                Anjir Rossiya
            </h1>
        </>
    )

}
export default Anjir;